export class News {
	public id: string;
	public title: string;
	public body: string;
	public picture: string;
	public thumb: string;
	public tags: string[];
}