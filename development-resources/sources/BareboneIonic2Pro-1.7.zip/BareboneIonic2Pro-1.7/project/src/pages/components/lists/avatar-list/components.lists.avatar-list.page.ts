
import { Component } from '@angular/core';


@Component({
    templateUrl: 'components.lists.avatar-list.html'
})
export class ComponentsListsAvatarListPage { }
