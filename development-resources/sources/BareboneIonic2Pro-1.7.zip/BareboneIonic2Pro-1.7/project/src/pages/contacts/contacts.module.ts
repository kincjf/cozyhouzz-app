import { IonicModule } from 'ionic-angular';
import { NgModule } from '@angular/core';

import { ContactsPage } from './contacts.page';

@NgModule({
	imports: [IonicModule],
	declarations: [ContactsPage],
	entryComponents: [ContactsPage]
})
export class ContactsModule {

}