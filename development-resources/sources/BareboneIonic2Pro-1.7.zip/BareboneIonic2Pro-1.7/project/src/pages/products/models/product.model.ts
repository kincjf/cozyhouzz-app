export class Product {
	public id: string;
	public title: string;
	public body: string;
	public pictures: string[];
}