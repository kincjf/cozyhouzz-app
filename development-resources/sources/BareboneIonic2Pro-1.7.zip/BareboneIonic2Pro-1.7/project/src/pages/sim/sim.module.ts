import { IonicModule } from 'ionic-angular';
import { NgModule } from '@angular/core';

import { SimPage } from './sim.page';

@NgModule({
	imports: [IonicModule],
	declarations: [SimPage],
	entryComponents: [SimPage]
})
export class SimModule {

}