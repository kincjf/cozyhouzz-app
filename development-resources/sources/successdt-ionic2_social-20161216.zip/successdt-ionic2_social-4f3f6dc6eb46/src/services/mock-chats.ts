export let CHATS = [
  {
    id: 0,
    name: 'Ben Sparrow',
    lastText: 'You on your way?',
    face: 'assets/img/thumb/ben.png',
    messages: [
      {
        type: 'received',
        text: 'Hey, How are you? wanna hang out this friday?',
        image: '',
        time: 'Thursday 05:55 PM'
      },
      {
        type: 'sent',
        text: 'Good, Yes sure why not :D',
        image: '',
        time: 'Thursday 05:56 PM'
      },
      {
        type: 'received',
        text: 'Check out this view from my last trip',
        image: '/assets/img/thumb/canada.jpg',
        time: 'Thursday 05:57 PM'
      },
      {
        type: 'sent',
        text: 'Looks Great is that view in Canada?',
        image: '',
        time: 'Thursday 05:58 PM'
      },
      {
        type: 'received',
        text: 'Yes, it\'s in Canada',
        image: '',
        time: 'Thursday 05:57 PM'
      }
    ]
  },
  {
    id: 1,
    name: 'Max Lynx',
    lastText: 'Hey, it\'s me',
    face: 'assets/img/thumb/max.png'
  },
  {
    id: 2,
    name: 'Adam Bradleyson',
    lastText: 'I should buy a boat',
    face: 'assets/img/thumb/adam.jpg'
  },
  {

    d: 3,
    name: 'Perry Governor',
    lastText: 'Look at my mukluks!',
    face: 'assets/img/thumb/perry.png'
  },
  {
    id: 4,
    name: 'Mike Harrington',
    lastText: 'This is wicked good ice cream.',
    face: 'assets/img/thumb/mike.png'
  },
  {
    id: 5,
    name: 'Ben Sparrow',
    lastText: 'You on your way?',
    face: 'assets/img/thumb/ben.png'
  },
  {
    id: 6,
    name: 'Max Lynx',
    lastText: 'Hey, it\'s me',
    face: 'assets/img/thumb/max.png'
  }
];