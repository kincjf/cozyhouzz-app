export class DrupalPost {
	public id: number;
	public title: string;
	public brief: string;
	public content: string;
	public image: string;
	public tags: string[];
}