import { Component } from '@angular/core';


@Component({
    templateUrl: 'components.icons.html'
})
export class ComponentsIconsPage { }
