export class Contact {
	constructor(
		public phoneNumbers: any,
		public photos: any,
		public displayName: string
	) {
	}
}