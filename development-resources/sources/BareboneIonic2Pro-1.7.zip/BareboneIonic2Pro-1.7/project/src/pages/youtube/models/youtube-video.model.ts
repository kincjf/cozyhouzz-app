export class YoutubeVideo {
	id: string;
	title: string;
	description: string;
	date: string;
	image: string;
	thumb: string;
	videoId: string;
}