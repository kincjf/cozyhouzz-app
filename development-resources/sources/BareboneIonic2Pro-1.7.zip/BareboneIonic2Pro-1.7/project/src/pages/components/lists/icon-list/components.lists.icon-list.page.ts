
import { Component } from '@angular/core';


@Component({
    templateUrl: 'components.lists.icon-list.html'
})
export class ComponentsListsIconListPage { }
