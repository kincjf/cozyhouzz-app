import { Component } from '@angular/core';


@Component({
  templateUrl: 'components.lists.thumbnail-list.html'
})
export class ComponentsListsThumbnailListPage { }
