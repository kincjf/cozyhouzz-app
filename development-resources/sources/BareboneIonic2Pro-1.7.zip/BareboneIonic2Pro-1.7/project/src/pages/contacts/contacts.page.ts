import { Component } from '@angular/core';
import { Contacts } from 'ionic-native';
import { Contact } from './contact';
import { isCordovaAvailable } from '../../services/is-cordova-available';

@Component({
	templateUrl: 'contacts.html'
})
export class ContactsPage {
	contacts: Contact[] = [];
	contactInfo: string[] = ['*'];
	searchFilter: string;

	constructor() {
	}

	findContacts() {
		if (!isCordovaAvailable()) {
			return false;
		}
		let options = {
			filter: this.searchFilter,
			multiple: true
		}
		this.contacts = [];

		Contacts.find(this.contactInfo, options).then(response => {
			console.log(response);
			this.contacts = response;
		});
	}
}
