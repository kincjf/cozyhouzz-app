export class NativeStorageItem {
	public title: string;
	public teaser: string;
	public id: string;
}