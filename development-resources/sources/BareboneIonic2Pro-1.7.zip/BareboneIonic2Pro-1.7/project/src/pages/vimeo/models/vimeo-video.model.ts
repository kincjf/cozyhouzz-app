export class VimeoVideo {
	id: string;
	title: string;
	description: string;
	date: string;
	image: string;
	thumb: string;
	videoId: string;
}