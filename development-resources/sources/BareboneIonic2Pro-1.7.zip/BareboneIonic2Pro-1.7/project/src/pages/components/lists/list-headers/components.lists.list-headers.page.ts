import { Component } from '@angular/core';


@Component({
    templateUrl: 'components.lists.list-headers.html'
})
export class ComponentsListsListHeadersPage { }
