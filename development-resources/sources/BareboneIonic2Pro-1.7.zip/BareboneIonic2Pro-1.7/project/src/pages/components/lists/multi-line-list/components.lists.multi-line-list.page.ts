import { Component } from '@angular/core';


@Component({
    templateUrl: 'components.lists.multi-line-list.html'
})
export class ComponentsListsMultiLineListPage { }
