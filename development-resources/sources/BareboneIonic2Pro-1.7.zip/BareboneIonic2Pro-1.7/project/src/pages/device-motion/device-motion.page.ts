import { Component, OnInit, OnDestroy } from '@angular/core';
import { DeviceMotion, AccelerationData } from 'ionic-native';
import { Subscription } from 'rxjs';
import { isCordovaAvailable } from '../../services/is-cordova-available';

@Component({
	templateUrl: 'device-motion.html'
})
export class DeviceMotionPage implements OnInit, OnDestroy {
	currentAcceleration: any;
	private subscription: Subscription;

	constructor() {
		DeviceMotion.getCurrentAcceleration().then(
			(acceleration: AccelerationData) => this.currentAcceleration = acceleration,
			(error: any) => console.log(error)
		);
	}

	ngOnInit() {
		if (!isCordovaAvailable()) {
			return false;
		}
		this.subscription = DeviceMotion.watchAcceleration({ frequency: 300 })
			.subscribe((acceleration: AccelerationData) => {
				console.log(JSON.stringify(acceleration));
				this.currentAcceleration = acceleration
			});
	}

	ngOnDestroy() {
		this.subscription.unsubscribe();
	}
}
