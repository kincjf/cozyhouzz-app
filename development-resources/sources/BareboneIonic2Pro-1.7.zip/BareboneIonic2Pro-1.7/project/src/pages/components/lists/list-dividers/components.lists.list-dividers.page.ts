import { Component } from '@angular/core';


@Component({
    templateUrl: 'components.lists.list-dividers.html'
})
export class ComponentsListsListDividersPage { }
