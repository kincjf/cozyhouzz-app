import {OnInit, Component} from "@angular/core";

@Component({
  templateUrl: "build/pages/terms-of-service/terms-of-service.html"
})

export class TermsOfServicePage {
  constructor() {
  }

  ngOnInit() {

  }
}
