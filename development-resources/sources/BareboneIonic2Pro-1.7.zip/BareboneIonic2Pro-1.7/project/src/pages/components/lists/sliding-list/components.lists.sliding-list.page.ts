import { Component } from '@angular/core';


@Component({
    templateUrl: 'components.lists.sliding-list.html'
})
export class ComponentsListsSlidingListPage { }
