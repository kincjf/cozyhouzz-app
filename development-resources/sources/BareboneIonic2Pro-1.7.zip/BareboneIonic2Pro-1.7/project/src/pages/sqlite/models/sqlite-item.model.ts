export class SqliteItem {
	public title: string;
	public teaser: string;
	public id: string;
}