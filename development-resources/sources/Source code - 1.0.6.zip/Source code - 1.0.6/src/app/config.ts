export class Config {
  public static FIREBASE_CONFIG = {
    apiKey: '',
    authDomain: '',
    databaseURL: '',
    storageBucket: ''
  };
  public static WEB_CLIENT_ID = '';
}
