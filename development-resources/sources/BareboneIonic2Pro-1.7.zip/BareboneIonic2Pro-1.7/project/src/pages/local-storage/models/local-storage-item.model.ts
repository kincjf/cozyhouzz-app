export class LocalStorageItem {
	public title: string;
	public teaser: string;
	public id: string;
}